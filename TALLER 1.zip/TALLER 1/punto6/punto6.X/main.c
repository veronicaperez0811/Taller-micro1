//Sem�foro

#include <xc.h>
#include "config.h"


void main(void){
    // Configuraci�n de puertos y pines.
    TRISD = 0x00; // Configura el puerto D como salida (para controlar LEDs).
    TRISAbits.TRISA0 = 1; // Configura el pin RA0 como entrada.
    ANSELAbits.ANSA0 = 0; 
    TRISAbits.TRISA1 = 1; // Configura el pin RA1 como entrada.
    ANSELAbits.ANSA1 = 0; 

    while(1){
        // Secuencia de encendido y apagado de LEDs en el puerto D.
        PORTD= 0b00101001; // Enciende los LEDs D0, D3, D5 y D7.
        __delay_ms(200); 
        PORTD= 0b00100110; // Enciende los LEDs D1, D2, D5 y D6.
        __delay_ms(200); 
        PORTD= 0b00011010; // Enciende los LEDs D2, D3, D5 y D6.
        __delay_ms(200); 
    }

    return;
}
