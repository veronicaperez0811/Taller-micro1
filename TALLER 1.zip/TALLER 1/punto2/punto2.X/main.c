/* Punto 2: Configura y controla un conjunto de LEDs conectados al puerto D, 
creando una secuencia de encendido ascendente y descendente
 Usando solo For y Mascaras de bits/*/

#include <xc.h>
#include "config.h"
#define te 500


void main(void){
    TRISD = 0x00;
    TRISAbits.TRISA0 = 1;
    ANSELAbits.ANSA0 = 0;
    TRISAbits.TRISA1 = 1;
    ANSELAbits.ANSA1 = 0;

    while(1){
        // Encender  en orden ascendente
        for (char i = 0; i < 8; i++) {
            PORTD = (1 << i);  
            __delay_ms(te);
        }
        
        // Encender  en orden descendente
        for (char i = 6; i >= 1; i--) {  
            PORTD = (1 << i);  
            __delay_ms(te);
        }
    }

    return;
}
