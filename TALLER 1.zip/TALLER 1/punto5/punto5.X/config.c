// PIC16F1939 Configuration Bit Settings

// 'C' source line config statements

// CONFIG1
#pragma config FOSC = HS        // Oscillator Selection (HS Oscillator, High-speed crystal/resonator connected between OSC1 and OSC2 pins)
#pragma config WDTE = OFF       // Watchdog Timer Enable (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable (PWRT disabled)
#pragma config MCLRE = ON       // MCLR Pin Function Select (MCLR/VPP pin function is MCLR)
#pragma config CP = OFF         // Flash Program Memory Code Protection (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Memory Code Protection (Data memory code protection is disabled)
#pragma config BOREN = ON       // Brown-out Reset Enable (Brown-out Reset enabled)
#pragma config CLKOUTEN = OFF   // Clock Out Enable (CLKOUT function is disabled. I/O or oscillator function on the CLKOUT pin)
#pragma config IESO = ON        // Internal/External Switchover (Internal/External Switchover mode is enabled)
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enable (Fail-Safe Clock Monitor is enabled)

// CONFIG2
#pragma config WRT = OFF        // Flash Memory Self-Write Protection (Write protection off)
#pragma config VCAPEN = OFF     // Voltage Regulator Capacitor Enable (All VCAP pin functionality is disabled)
#pragma config PLLEN = OFF      // PLL Enable (4x PLL disabled)
#pragma config STVREN = ON      // Stack Overflow/Underflow Reset Enable (Stack Overflow or Underflow will cause a Reset)
#pragma config BORV = LO        // Brown-out Reset Voltage Selection (Brown-out Reset Voltage (Vbor), low trip point selected.)
      // In-Circuit Debugger Mode (In-Circuit Debugger disabled, ICSPCLK and ICSPDAT are general purpose I/O pins)
#pragma config LVP = OFF        // Low-Voltage Programming Enable (High-voltage on MCLR/VPP must be used for programming)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#include "config.h"

void Secuencia00(){
     // Apaga todos los LEDs para comenzar.
    LATD = 0;
    __delay_ms(200);
}

void Secuencia01(){
   
    // Enciende los LEDs en D0 y D7.
    LATD = 0b10000001;
    __delay_ms(200);
    LATD = 0;  // Apaga todos los LEDs.
    __delay_ms(200);
}
void Secuencia02(){
    // Enciende los LEDs en D0, D1, D6 y D7.
    LATD = 0b11000011;
    __delay_ms(200);
    LATD = 0;  // Apaga todos los LEDs.
    __delay_ms(200);
}
void Secuencia03(){
   // Enciende los LEDs en D7, D6 y D5.
    LATD = 0b11100000;
    __delay_ms(200);
    // Apaga D6 y D5, y enciende D1 y D2.
    LATD = 0b00000110;
    __delay_ms(200);
    LATD = 0;  // Apaga todos los LEDs.
    __delay_ms(200);
}
void Secuencia04(){
     // Enciende los LEDs D1, D2 y D3.
    LATD = 0b00001110;
    __delay_ms(200);
    // Enciende los LEDs D7, D6 y D5.
    LATD = 0b11100000;
    __delay_ms(200);
    LATD = 0;  // Apaga todos los LEDs.
    __delay_ms(200);
}
void Secuencia05(){
   // Enciende todos los LEDs.
    LATD = 0b11111111;
    __delay_ms(200);
    // Deja encendido solo D1.
    LATD = 0b00000010;
    __delay_ms(200);
    LATD = 0;  // Apaga todos los LEDs.
    __delay_ms(200);
}
void Secuencia06(){
   // Enciende los LEDs D2, D4 y D6.
    LATD = 0b01010100;
    __delay_ms(200);
    // Apaga D2, D4 y D6, y enciende D1, D3, D5 y D7.
    LATD = 0b10101010;
    __delay_ms(200);
    LATD = 0;  // Apaga todos los LEDs.
    __delay_ms(200);
}
void Secuencia07(){
  // Enciende los LEDs D1 y D2.
    LATD = 0b00000011;
    __delay_ms(200);
    // Enciende los LEDs D4 y D5.
    LATD = 0b00011011;
    __delay_ms(200);
    // Enciende solo el LED D7.
    LATD = 0b10000000;
    __delay_ms(200);
    LATD = 0;  // Apaga todos los LEDs.
    __delay_ms(200);
}
void Secuencia08(){
   // Enciende los LEDs D7 y D0.
    LATD = 0b10000001;
    __delay_ms(200);
    // Enciende los LEDs D6 y D1.
    LATD = 0b01000010;
    __delay_ms(200);
    // Enciende los LEDs D5 y D2.
    LATD = 0b00100100;
    __delay_ms(200);
    // Enciende los LEDs D4 y D3.
    LATD = 0b00011000;
    __delay_ms(200);
    LATD = 0;  // Apaga todos los LEDs.
    __delay_ms(200);
}

void Secuencia09(){
      // Enciende todos los LEDs.
    LATD = 0b11111111;
    __delay_ms(200);
    // Enciende solo los LEDs D0 y D7.
    LATD = 0b10000001;
    __delay_ms(200);
    LATD = 0;  // Apaga todos los LEDs.
    __delay_ms(200);
}


