/* Punto 4: ENTRADA Y SALIDA DIGITAL
 * Presiona 3 veces y cambia la salida/*/

#include <xc.h>
#include "config.h"

char contador = 0;

void main(void) {
   
    TRISBbits.TRISB0 = 1; // RB0 como entrada 
    ANSELBbits.ANSB0 = 0; // RB0 como entrada digital
    TRISBbits.TRISB7 = 0; // RB7 como salida (LED)
    
    TRISD = 0x00; // puerto D como salida 
    PORTD = 0x00; // inicializa  apagado
    
    while (1) {
        // Verificar si el bot�n en RB0 est� presionado 
        if (PORTBbits.RB0 == 0) {
            // Esperar a que se suelte el bot�n
            while (PORTBbits.RB0 == 0);
            
            // Incrementar el contador y verificar si es igual a 3
            contador++;
            if (contador == 3) {
                // Invertir el estado en RB7
                LATBbits.LATB7 ^= 1;
            }
        }
        
        __delay_ms(100);
    }
    
    return;
}


