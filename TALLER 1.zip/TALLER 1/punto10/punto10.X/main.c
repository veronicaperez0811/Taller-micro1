#include <xc.h>
#include "config.h"

void main(void) {
 
    ANSELB = 0x00; 
    TRISDbits.TRISD0 = 0; //RD0 como salida
    TRISBbits.TRISB0 = 1; //RB0 como entrada
    TRISBbits.TRISB1 = 1; //RB1 como entrada
    
    while (1) { 
        if (PORTBbits.RB0 == 0) { 
            while (PORTBbits.RB0 == 0);
            
            // Invertir el estado de RD0 (LED) utilizando XOR
            LATDbits.LATD0 ^= 1;
            
            __delay_ms(100);
        }
     
        if (PORTBbits.RB1 == 0) {

            while (PORTBbits.RB1 == 0);
            
            // Invertir el estado de RD0 (LED) utilizando XOR
            LATDbits.LATD0 ^= 1;

            __delay_ms(100);
        }
    }
    
    return;
}

