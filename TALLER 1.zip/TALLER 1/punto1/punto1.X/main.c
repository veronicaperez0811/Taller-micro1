/* Punto 1: Configura y controla un conjunto de LEDs conectados al puerto D, 
creando una secuencia de encendido ascendente y descendente/*/

#include <xc.h>
#include "config.h"
#define te 100



void main(void){
    //Puerto D salidas 
    //RA0, RA1 entradas digitales
    TRISD = 0x00;
    TRISAbits.TRISA0 = 1;
    ANSELAbits.ANSA0 = 0;
    TRISAbits.TRISA1 = 1;
    ANSELAbits.ANSA1 = 0;

    while(1){
        // Encender los LEDs en orden ascendente
        char i = 0;//se utiliza como un contador para controlar cu�l LED se enciende
        while (i < 8) {
            PORTD = (1 << i);  // Encender  LED
            __delay_ms(te);
            i++;
        }
        
        // Devolverse
        i = 6; 
        while (i >= 1) {
            PORTD = (1 << i);  // Encender  LED
            __delay_ms(te);
            i--;
        }
    }

    return;
}