/* 
 * File:   config.h
 * Author: Veronica
 *
 * Created on 11 de agosto de 2023, 08:17 AM
 */

#ifndef CONFIG_H
#define	CONFIG_H

#define _XTAL_FREQ 20000000UL

#endif	/* CONFIG_H */


